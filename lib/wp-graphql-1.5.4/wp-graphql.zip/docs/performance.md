---
uri: "/docs/performance/"
title: "Performance"
---

Add some interesting performance details here.
