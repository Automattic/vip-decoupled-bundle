---
uri: "/docs/widgets/"
title: "Widgets"
---

WPGraphQL currently does not support queries or mutations for widgets. 

Widgets don't have a proper server registry so it's difficult to provide formal WPGraphQL support for querying and/or mutating Widgets.

[Read more about the decision not to officially support widgets](https://github.com/wp-graphql/wp-graphql/issues/20#issuecomment-554426933).
